# Nullworx — ASCII Waves / Flower field

Version: 0.1.0
Effect ID: nwx-ascii-waves
Status: OWNER_REVIEW
Generated: 2026-10-28

A video is sampled cell by cell, translated into a living field of characters, and pushed through a slow wave of light.

## Review status

This is an owner-review artifact, not a released Nullworx effect. Do not present it as a Nullworx release until an explicit release approval is recorded.

## Install

```sh
unzip ascii-waves-0.1.0.zip -d .
```

The files are:
- components/effects/ascii-waves/ascii-waves.tsx (sha256 b679afe2693c3bdc207a41bd0f28907ffaa4da5ef2b257bfce36b7ff0c4d2d03)
- components/effects/ascii-waves/ascii-waves.module.css (sha256 4784f3b073a15bb84bff14e18d5ca5bd1448f4d5cd94e4097ec209789733475b)
- components/effects/ascii-waves/renderer.ts (sha256 edd2ab3a049ed2c2a70b8cd62043134163463246516ba06cdf7d6fe9e12aafd7)
- components/effects/ascii-waves/glyphAtlas.ts (sha256 eb002aa7ce2875db3afeafebb596d0e32633acd4a4fdeb10ab95886c5be950f2)
- components/effects/ascii-waves/presets.ts (sha256 f4418e448209e0176c019f95dde35e42f1a9ae6d0381bb1540d91918ed666de3)
- public/media/flower.mp4 (sha256 0cd83d944a6ca7822b4a8306cecc60a36e859b041f6702c6a1ad9ead78924451)
- public/media/motifs/flower-poster.jpg (sha256 fb34be9b63ad42c7b13dae6c507e683c09f623cc7380ca6717959d54554e919a)

## Usage

```tsx
"use client";

import { AsciiWaves } from "@/components/effects/ascii-waves/ascii-waves";

export function Field() {
  return (
    <div style={{ width: "100%", aspectRatio: "16 / 9" }}>
      <AsciiWaves
        preset="flower"
        cellSize="auto"
        speed={1}
        quality="balanced"
        muted
        loop
        reducedMotion="system"
        ariaLabel="ASCII wave field made from a flower video"
      />
    </div>
  );
}
```

## Licensing

Code: MIT. The Nullworx site and effect code are offered under the repository's MIT license. The Flower video and poster are CC0 1.0 from the MDN sample media. The component itself does not bundle fonts; it draws from the system monospace stack.
Media: CC0 1.0. Source and credit details are in public/media/credits/flower.md.

## Notes

- The bundle preserves the reviewed five-file component layout and the CC0 media.
- The reviewed usage mutes the video and the component defaults to muted playback. Keep `muted` set unless you provide your own user-initiated audio path.
- Set an explicit parent height. A zero-height parent produces a zero-height field.
- Distribution remains gated: this archive is a review artifact until the effect is RELEASED.

No email, analytics or account data is included in this archive.
